package com.bidding.system.bidding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiddingApplicationTests {

	@Test
	void contextLoads() {
	}

}
