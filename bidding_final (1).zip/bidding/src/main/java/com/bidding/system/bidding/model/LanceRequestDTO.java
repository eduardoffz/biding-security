package com.bidding.system.bidding.model;

import java.math.BigDecimal;

public class LanceRequestDTO {
    private BigDecimal valor;

    public LanceRequestDTO() {}

    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
}
