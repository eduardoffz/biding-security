package com.bidding.system.bidding.repository;

import com.bidding.system.bidding.model.LanceDTO;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class LanceRepository {

    public void criar(LanceDTO lance) {
        String sql = "INSERT INTO lances (valor, id_edital, id_usuario) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setBigDecimal(1, lance.getValor());
            stmt.setLong(2, lance.getIdEdital());
            stmt.setLong(3, lance.getIdUsuario());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Retorna TODOS os lances de um edital (para edital ENCERRADO)
    public List<LanceDTO> listarPorEdital(Long idEdital) {
        List<LanceDTO> lista = new ArrayList<>();
        String sql = """
                SELECT l.id, l.valor, l.data_lance, l.id_edital, l.id_usuario, u.nome
                FROM lances l
                JOIN usuarios u ON u.id = l.id_usuario
                WHERE l.id_edital = ?
                ORDER BY l.valor ASC
                """;
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, idEdital);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Retorna apenas o lance do próprio usuário (para edital ABERTO)
    public List<LanceDTO> listarPorEditalEUsuario(Long idEdital, Long idUsuario) {
        List<LanceDTO> lista = new ArrayList<>();
        String sql = """
                SELECT l.id, l.valor, l.data_lance, l.id_edital, l.id_usuario, u.nome
                FROM lances l
                JOIN usuarios u ON u.id = l.id_usuario
                WHERE l.id_edital = ? AND l.id_usuario = ?
                ORDER BY l.data_lance DESC
                """;
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, idEdital);
            stmt.setLong(2, idUsuario);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private LanceDTO mapear(ResultSet rs) throws SQLException {
        LanceDTO l = new LanceDTO();
        l.setId(rs.getLong("id"));
        l.setValor(rs.getBigDecimal("valor"));
        l.setDataLance(rs.getTimestamp("data_lance").toLocalDateTime());
        l.setIdEdital(rs.getLong("id_edital"));
        l.setIdUsuario(rs.getLong("id_usuario"));
        l.setNomeUsuario(rs.getString("nome"));
        return l;
    }
}
