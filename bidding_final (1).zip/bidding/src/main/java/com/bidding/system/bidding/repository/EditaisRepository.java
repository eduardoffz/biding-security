package com.bidding.system.bidding.repository;

import com.bidding.system.bidding.model.EditaisDTO;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Repository
public class EditaisRepository {

    public void criar(EditaisDTO edital) {
        String sql = "INSERT INTO editais (titulo, descricao, data_fechamento, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, edital.getTitulo());
            stmt.setString(2, edital.getDescricao());
            stmt.setTimestamp(3, Timestamp.valueOf(edital.getDataFechamento()));
            stmt.setString(4, edital.getStatus() != null ? edital.getStatus() : "ABERTO");

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<EditaisDTO> listarTodos() {
        List<EditaisDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM editais";
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public EditaisDTO buscarPorId(Long id) {
        String sql = "SELECT * FROM editais WHERE id = ?";
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapear(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private EditaisDTO mapear(ResultSet rs) throws SQLException {
        EditaisDTO e = new EditaisDTO();
        e.setId(rs.getLong("id"));
        e.setTitulo(rs.getString("titulo"));
        e.setDescricao(rs.getString("descricao"));
        e.setDataFechamento(rs.getTimestamp("data_fechamento").toLocalDateTime());
        e.setStatus(rs.getString("status"));
        return e;
    }
}
