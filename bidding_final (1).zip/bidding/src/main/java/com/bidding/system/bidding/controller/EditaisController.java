package com.bidding.system.bidding.controller;

import com.bidding.system.bidding.model.EditaisDTO;
import com.bidding.system.bidding.service.EditaisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/editais")
public class EditaisController {

    @Autowired
    private EditaisService editaisService;

    /**
     * POST /api/editais
     * Apenas COMPRADOR (controlado pelo SecurityConfig)
     * Body: { "titulo": "...", "descricao": "...", "dataFechamento": "2026-12-31T23:59:59", "status": "ABERTO" }
     */
    @PostMapping
    public ResponseEntity<String> criar(@RequestBody EditaisDTO edital) {
        editaisService.criar(edital);
        return ResponseEntity.status(201).body("Edital criado com sucesso");
    }

    /**
     * GET /api/editais
     * Qualquer usuário autenticado
     */
    @GetMapping
    public ResponseEntity<List<EditaisDTO>> listar() {
        return ResponseEntity.ok(editaisService.listarTodos());
    }
}
