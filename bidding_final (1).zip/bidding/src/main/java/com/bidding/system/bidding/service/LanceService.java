package com.bidding.system.bidding.service;

import com.bidding.system.bidding.model.EditaisDTO;
import com.bidding.system.bidding.model.LanceDTO;
import com.bidding.system.bidding.model.LanceRequestDTO;
import com.bidding.system.bidding.model.UserDTO;
import com.bidding.system.bidding.repository.LanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class LanceService {

    @Autowired
    private LanceRepository lanceRepository;

    @Autowired
    private EditaisService editaisService;

    /**
     * Cria um lance.
     * - id_usuario extraído do token (SecurityContextHolder)
     * - Bloqueia se edital ENCERRADO ou data_fechamento ultrapassada
     */
    public void criar(Long idEdital, LanceRequestDTO request, UserDTO usuarioLogado) {
        if (request.getValor() == null || request.getValor().signum() <= 0) {
            throw new ResponseStatusException(HttpStatusCode.valueOf(400), "Valor do lance deve ser positivo");
        }

        EditaisDTO edital = editaisService.buscarPorId(idEdital);

        // Regra: edital encerrado
        if ("ENCERRADO".equals(edital.getStatus())) {
            throw new ResponseStatusException(HttpStatusCode.valueOf(422), "Este edital já está encerrado");
        }

        // Regra: data_fechamento ultrapassada
        if (LocalDateTime.now().isAfter(edital.getDataFechamento())) {
            throw new ResponseStatusException(HttpStatusCode.valueOf(422), "O prazo para envio de lances encerrou em " + edital.getDataFechamento());
        }

        LanceDTO lance = new LanceDTO();
        lance.setValor(request.getValor());
        lance.setIdEdital(idEdital);
        lance.setIdUsuario(usuarioLogado.getId()); // ID vem do TOKEN, nunca do body

        lanceRepository.criar(lance);
    }

    /**
     * Regra de visibilidade:
     * - Edital ABERTO → fornecedor vê APENAS seu próprio lance
     * - Edital ENCERRADO → todos os lances liberados (ordenados por menor valor)
     */
    public List<LanceDTO> listar(Long idEdital, UserDTO usuarioLogado) {
        EditaisDTO edital = editaisService.buscarPorId(idEdital);

        if ("ENCERRADO".equals(edital.getStatus())) {
            return lanceRepository.listarPorEdital(idEdital);
        } else {
            return lanceRepository.listarPorEditalEUsuario(idEdital, usuarioLogado.getId());
        }
    }
}
