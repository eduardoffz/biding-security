package com.bidding.system.bidding.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class LanceDTO {
    private Long id;
    private BigDecimal valor;
    private LocalDateTime dataLance;
    private Long idEdital;
    private Long idUsuario;
    private String nomeUsuario;

    public LanceDTO() {}

    public LanceDTO(Long id, BigDecimal valor, LocalDateTime dataLance, Long idEdital, Long idUsuario, String nomeUsuario) {
        this.id = id;
        this.valor = valor;
        this.dataLance = dataLance;
        this.idEdital = idEdital;
        this.idUsuario = idUsuario;
        this.nomeUsuario = nomeUsuario;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }

    public LocalDateTime getDataLance() { return dataLance; }
    public void setDataLance(LocalDateTime dataLance) { this.dataLance = dataLance; }

    public Long getIdEdital() { return idEdital; }
    public void setIdEdital(Long idEdital) { this.idEdital = idEdital; }

    public Long getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Long idUsuario) { this.idUsuario = idUsuario; }

    public String getNomeUsuario() { return nomeUsuario; }
    public void setNomeUsuario(String nomeUsuario) { this.nomeUsuario = nomeUsuario; }
}
