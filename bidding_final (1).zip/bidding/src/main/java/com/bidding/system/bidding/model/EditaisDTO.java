package com.bidding.system.bidding.model;

import java.time.LocalDateTime;

public class EditaisDTO {
    private Long id;
    private String titulo;
    private String descricao;
    private LocalDateTime dataFechamento;
    private String status;

    public EditaisDTO() {}

    public EditaisDTO(Long id, String titulo, String descricao, LocalDateTime dataFechamento, String status) {
        this.id = id;
        this.titulo = titulo;
        this.descricao = descricao;
        this.dataFechamento = dataFechamento;
        this.status = status;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public LocalDateTime getDataFechamento() { return dataFechamento; }
    public void setDataFechamento(LocalDateTime dataFechamento) { this.dataFechamento = dataFechamento; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
