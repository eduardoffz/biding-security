package com.bidding.system.bidding.controller;

import com.bidding.system.bidding.model.LanceDTO;
import com.bidding.system.bidding.model.LanceRequestDTO;
import com.bidding.system.bidding.model.UserDTO;
import com.bidding.system.bidding.service.LanceService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/editais/{idEdital}/lances")
public class LanceController {

    @Autowired
    private LanceService lanceService;

    /**
     * POST /api/editais/{idEdital}/lances
     * Apenas FORNECEDOR (controlado pelo SecurityConfig)
     * Body: { "valor": 9999.99 }
     * O id_usuario é extraído do Token JWT — nunca do body.
     */
    @PostMapping
    public ResponseEntity<String> enviarLance(
            @PathVariable Long idEdital,
            @RequestBody LanceRequestDTO request,
            HttpServletRequest httpRequest) {

        UserDTO usuarioLogado = (UserDTO) httpRequest.getAttribute("usuarioLogado");
        lanceService.criar(idEdital, request, usuarioLogado);
        return ResponseEntity.status(201).body("Lance enviado com sucesso");
    }

    /**
     * GET /api/editais/{idEdital}/lances
     * Regra de visibilidade:
     *   - ABERTO  → fornecedor vê apenas o seu próprio lance
     *   - ENCERRADO → todos os lances visíveis, ordenados por menor valor
     */
    @GetMapping
    public ResponseEntity<List<LanceDTO>> listarLances(
            @PathVariable Long idEdital,
            HttpServletRequest httpRequest) {

        UserDTO usuarioLogado = (UserDTO) httpRequest.getAttribute("usuarioLogado");
        return ResponseEntity.ok(lanceService.listar(idEdital, usuarioLogado));
    }
}
