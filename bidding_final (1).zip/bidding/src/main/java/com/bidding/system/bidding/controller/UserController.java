package com.bidding.system.bidding.controller;

import com.bidding.system.bidding.model.UserDTO;
import com.bidding.system.bidding.model.UserRequestDTO;
import com.bidding.system.bidding.service.TokenService;
import com.bidding.system.bidding.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private TokenService tokenService;

    // POST /api/users/register
    // Body: { "nome": "...", "email": "...", "senha": "...", "role": "..." }
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody UserDTO user) {
        userService.register(user);
        return ResponseEntity.status(201).body("Usuário cadastrado com sucesso");
    }

    // POST /api/users/login
    // Body: { "email": "...", "senha": "..." }
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody UserRequestDTO request) {
        UserDTO user = userService.logar(request);
        String token = tokenService.gerarToken(user);
        return ResponseEntity.ok(token);
    }
}
