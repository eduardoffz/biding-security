package com.bidding.system.bidding.service;

import com.bidding.system.bidding.model.EditaisDTO;
import com.bidding.system.bidding.repository.EditaisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class EditaisService {

    @Autowired
    private EditaisRepository repository;

    public void criar(EditaisDTO edital) {
        if (edital.getTitulo() == null || edital.getTitulo().isBlank()) {
            throw new ResponseStatusException(HttpStatusCode.valueOf(400), "Título é obrigatório");
        }
        if (edital.getDataFechamento() == null) {
            throw new ResponseStatusException(HttpStatusCode.valueOf(400), "Data de fechamento é obrigatória");
        }
        if (edital.getStatus() == null || edital.getStatus().isBlank()) {
            edital.setStatus("ABERTO");
        }
        repository.criar(edital);
    }

    public List<EditaisDTO> listarTodos() {
        return repository.listarTodos();
    }

    public EditaisDTO buscarPorId(Long id) {
        EditaisDTO edital = repository.buscarPorId(id);
        if (edital == null) {
            throw new ResponseStatusException(HttpStatusCode.valueOf(404), "Edital não encontrado");
        }
        return edital;
    }
}
