package com.bidding.system.frontend.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

public class LanceDTO {
    private Long id;
    @NotNull @Positive private BigDecimal valor;
    private String fornecedorEmail;
    private Long editalId;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
    public String getFornecedorEmail() { return fornecedorEmail; }
    public void setFornecedorEmail(String fornecedorEmail) { this.fornecedorEmail = fornecedorEmail; }
    public Long getEditalId() { return editalId; }
    public void setEditalId(Long editalId) { this.editalId = editalId; }
}