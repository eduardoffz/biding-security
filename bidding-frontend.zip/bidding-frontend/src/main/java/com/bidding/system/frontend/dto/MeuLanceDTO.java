package com.bidding.system.frontend.dto;

import java.math.BigDecimal;

public class MeuLanceDTO {
    private Long id;
    private String tituloEdital;
    private BigDecimal valor;
    private String statusEdital;
    private boolean vencedor;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTituloEdital() { return tituloEdital; }
    public void setTituloEdital(String tituloEdital) { this.tituloEdital = tituloEdital; }
    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
    public String getStatusEdital() { return statusEdital; }
    public void setStatusEdital(String statusEdital) { this.statusEdital = statusEdital; }
    public boolean isVencedor() { return vencedor; }
    public void setVencedor(boolean vencedor) { this.vencedor = vencedor; }
}