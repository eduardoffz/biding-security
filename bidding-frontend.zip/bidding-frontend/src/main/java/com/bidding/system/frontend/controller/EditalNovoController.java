package com.bidding.system.frontend.controller;

import com.bidding.system.frontend.dto.Dtos.*;
import com.bidding.system.frontend.service.ApiService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;

// Exercício 5 - Criar edital (somente teste do  COMPRADOR)
@Controller
public class EditalNovoController {

    private final ApiService apiService;

    public EditalNovoController(ApiService apiService) {
        this.apiService = apiService;
    }

    // GET /editais/novo
    @GetMapping("/editais/novo")
    public String novoEditalPage(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        String role = (String) session.getAttribute("role");

        if (token == null) return "redirect:/login";

        // Exercício 5 - apenas COMPRADOR pode acessar
        if (!"COMPRADOR".equals(role)) {
            model.addAttribute("erro", "Acesso negado. Apenas compradores podem criar editais.");
            return "erro";
        }

        return "novo-edital";
    }

    // POST /editais/novo
    @PostMapping("/editais/novo")
    public String criarEdital(@RequestParam String titulo,
                               @RequestParam String descricao,
                               @RequestParam String dataFechamento,
                               HttpSession session,
                               Model model) {
        String token = (String) session.getAttribute("token");
        String role = (String) session.getAttribute("role");

        if (token == null) return "redirect:/login";

        if (!"COMPRADOR".equals(role)) {
            model.addAttribute("erro", "Acesso negado.");
            return "erro";
        }

        try {
            // dataFechamento vem     como "yyyy-MM-ddTHH:mm" do input datetime-local
            EditalDTO edital = new EditalDTO(titulo, descricao, dataFechamento, "ABERTO");
            apiService.criarEdital(edital, token);
            return "redirect:/editais";
        } catch (HttpClientErrorException.Forbidden e) {
            
            
            // Exercício 5 do retorm - backend retornou 403
            model.addAttribute("erro", "Você não tem permissão para criar editais.");
            return "novo-edital";
        } catch (HttpClientErrorException e) {
            model.addAttribute("erro", "Erro ao criar edital: " + e.getResponseBodyAsString());
            return "novo-edital";
        } catch (Exception e) {
            model.addAttribute("erro", "Erro ao conectar com o servidor.");
            return "novo-edital";
        }
    }
}
